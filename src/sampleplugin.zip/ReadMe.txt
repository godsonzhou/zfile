fsplugin - plugin for Windows Commander 5.5 and newer.

This plugin only accesses the local drives of your computer
to show how plugins work. It is a sample plugin useful mainly
for plugin writers to understand the concept and start writing
their own plugins. You are allowed to modify the plugin to
your needs, but you are required to change at least the name
returned by FsGetDefRootName.

How to install the plugin in Windows Commander:
1. Unzip the archive to an empty directory
2. Choose Configuration - Options - Operation - FS-Plugins
3. Click "Add"
4. Go to the "Debug" subdirectory and choose fsplugin.wfx
5. Click OK. You can now access the plugin in "Network Neighborhood"

Author:
Christian Ghisler
http://www.ghisler.com